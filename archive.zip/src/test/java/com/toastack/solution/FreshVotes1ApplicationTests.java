package com.toastack.solution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreshVotes1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
